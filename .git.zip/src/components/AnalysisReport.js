import React from "react";

const AnalysisReport = ({ analysis }) => {
  if (!analysis) return null;

  return (
    <div>
      <h3>Analysis Report</h3>
      <p><strong>Total Sentences:</strong> {analysis.sentenceCount}</p>
      <h4>Word Frequency:</h4>
      <ul>
        {Object.entries(analysis.wordFrequency).map(([word, count]) => (
          <li key={word}>
            {word}: {count}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AnalysisReport;
